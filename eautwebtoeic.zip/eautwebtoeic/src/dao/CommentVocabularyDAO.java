package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import bean.Cmtvocabulary;

public class CommentVocabularyDAO {

	public static void insertCmtVocabulary(HttpServletRequest request, Connection conn, Cmtvocabulary cmtvocabulary) {
		PreparedStatement ptmt = null;

		String sql = "insert into cmtvocabulary(cmtvocabularycontent,memberid,vocabularyguidelineid) values (?,?,?)";

		try {
			ptmt = conn.prepareStatement(sql);
			
			String cmtvocabularycontent = cmtvocabulary.getCmtvocabularycontent();
			int memberid = cmtvocabulary.getMemberid();
			int vocabularyguidelineid = cmtvocabulary.getVocabularyguidelineid();
			
			ptmt.setString(1, cmtvocabularycontent);
			ptmt.setInt(2, memberid);
			ptmt.setInt(3, vocabularyguidelineid);
			
			ptmt.executeUpdate();
			ptmt.close();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//xuat ten cua thanh vien theo ma
	public static String Namemember(Connection conn,int memberid)
	{
		String name = "";
		
		
		String sql = "select name from member where memberid="+memberid;
		
		try 
		{
			PreparedStatement ptmt = conn.prepareStatement(sql);
			
			ResultSet rs = ptmt.executeQuery();
			
			rs.next();
			
			name = rs.getString("name");
			
				
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		return name;
	}

	
	public static List<Cmtvocabulary> displayCmtVocabulary(Connection conn, int vocabularyguidelineid){
		List<Cmtvocabulary> list = new ArrayList<Cmtvocabulary>();
		String sql = "select * from cmtvocabulary where vocabularyguidelineid="+vocabularyguidelineid;
		
		try {
			PreparedStatement ptmt = conn.prepareStatement(sql);
			ResultSet rs = ptmt.executeQuery();
			while(rs.next()) {
				Cmtvocabulary cmtvocabulary = new Cmtvocabulary();
				int memberid = rs.getInt("memberid");
				String cmtvocabularycontent = rs.getString("cmtvocabularycontent");
				String name = CommentVocabularyDAO.Namemember(conn, memberid);
				
				cmtvocabulary.setCmtvocabularycontent(cmtvocabularycontent);
				cmtvocabulary.setName(name);
				
				list.add(cmtvocabulary);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	public static int Countrow(Connection conn,int vocabularyguidelineid)
	{
		int count = 0;
		
		
		String sql = "select count(*) from cmtvocabulary where vocabularyguidelineid="+vocabularyguidelineid;
		
		try 
		{
			PreparedStatement ptmt = conn.prepareStatement(sql);
			
			ResultSet rs = ptmt.executeQuery();
			
			rs.next();
			
			count = rs.getInt(1);
			
				
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		
		return count;
	}
}


