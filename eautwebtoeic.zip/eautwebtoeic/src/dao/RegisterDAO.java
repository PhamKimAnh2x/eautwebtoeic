package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import bean.Member;

public class RegisterDAO 
{
	public static boolean InsertAccount(HttpServletRequest request, Connection conn, Member member)
	{
		PreparedStatement ptmt = null;
		
		String sql = "insert into member(name,membername,memberpass,categorymemberid) values (?,?,?,?)";
		
		try 
		{
			ptmt = conn.prepareStatement(sql);
			
			String name = member.getName();
			String membername = member.getMembername();
			String memberpass = member.getMemberpass();
			int categorymemberid = 1;
			
			ptmt.setString(1,name);
			ptmt.setString(2,membername);
			ptmt.setString(3,memberpass);
			ptmt.setInt(4,categorymemberid);
			
			int kt = ptmt.executeUpdate();
			
			if (kt != 0)
			{
				return true;
			}
			
			ptmt.close();
		} 
		catch (SQLException e) 
		{
			request.setAttribute("msgregister",e.getMessage());
		}
		
		return false;
		
	}
	
	public static Member checkAccountUserExist(HttpServletRequest request,Connection conn, String membername)
	{
		PreparedStatement ptmt = null;
		
		
		String sql = "select * from member where membername='"+membername+"'";
		
		try 
		{
			ptmt = conn.prepareStatement(sql);
			
			
			ResultSet rs = ptmt.executeQuery();
			
			while (rs.next())
			{
				return new Member(rs.getInt(1), 
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getInt(5));
			}
			
			ptmt.close();
			rs.close();
		} 
		catch (SQLException e) 
		{
			request.setAttribute("msgregister",e.getMessage());
		}
		
		return null;
	}
}
