package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import bean.Examination;
import bean.Grammarguideline;
import bean.Listenexercise;
import bean.Readexercise;
import bean.Vocabularyguideline;

public class SearchDAO 
{
	public static List<Grammarguideline> displayResult (HttpServletRequest request,Connection conn, String name1)
	{
		List<Grammarguideline> list = new ArrayList<Grammarguideline>();
		
		String sql = "select * from grammarguideline where grammarname like '%"+name1+"%'";
		try 
		{
			PreparedStatement ptmt = conn.prepareStatement(sql);
			
			ResultSet rs = ptmt.executeQuery();
			
			if (!rs.isBeforeFirst())
			{
				request.setAttribute("ketqua","Không có kết quả");
			}
			else 
			{
				while (rs.next())
				{
					Grammarguideline grammarguideline = new Grammarguideline();
					int grammarguidelineid = rs.getInt("grammarguidelineid");
					String grammarname = rs.getString("grammarname");
					String grammarimage = rs.getString("grammarimage");
					
					grammarguideline.setGrammarguidelineid(grammarguidelineid);
					grammarguideline.setGrammarname(grammarname);
					grammarguideline.setGrammarimage(grammarimage);
					
					list.add(grammarguideline);
				}
			}
			
		} 
		catch (SQLException e) 
		{
			request.setAttribute("ketqua",e.getMessage());
		}
		
		return list;
	}
	
	public static List<Vocabularyguideline> displayVocabularyResult (HttpServletRequest request,Connection conn, String name)
	{
		List<Vocabularyguideline> list = new ArrayList<Vocabularyguideline>();
		
		String sql = "select * from vocabularyguideline where vocabularyname like '%"+name+"%'";
		try 
		{
			PreparedStatement ptmt = conn.prepareStatement(sql);
			
			ResultSet rs = ptmt.executeQuery();
			
			if (!rs.isBeforeFirst())
			{
				request.setAttribute("ketqua","Không có kết quả");
			}
			else 
			{
				while (rs.next())
				{
					Vocabularyguideline vocabularyguideline = new Vocabularyguideline();
					int vocabularyguidelineid = rs.getInt("vocabularyguidelineid");
					String vocabularyname = rs.getString("vocabularyname");
					String vocabularyimage = rs.getString("vocabularyimage");
					
					vocabularyguideline.setVocabularyguidelineid(vocabularyguidelineid);
					vocabularyguideline.setVocabularyname(vocabularyname);
					vocabularyguideline.setVocabularyimage(vocabularyimage);
					
					list.add(vocabularyguideline);
				}
			}
			
		} 
		catch (SQLException e) 
		{
			request.setAttribute("ketqua",e.getMessage());
		}
		
		return list;
	}
	
	//tim kiem bai tap doc
	public static List<Readexercise> displayReadexerciseResult (HttpServletRequest request,Connection conn, String name2)
	{
		List<Readexercise> list = new ArrayList<Readexercise>();
		
		String sql = "select * from readexercise where readname like '%"+name2+"%'";
		try 
		{
			PreparedStatement ptmt = conn.prepareStatement(sql);
			
			ResultSet rs = ptmt.executeQuery();
			
			if (!rs.isBeforeFirst())
			{
				request.setAttribute("ketqua","Không có kết quả");
			}
			else 
			{
				while (rs.next())
				{
					Readexercise readexercise = new Readexercise();
					int readexeriseid = rs.getInt("readexeriseid");
					String readname = rs.getString("readname");
					String readimage = rs.getString("readimage");

					readexercise.setReadexeriseid(readexeriseid);
					readexercise.setReadname(readname);
					readexercise.setReadimage(readimage);
					
					list.add(readexercise);
				}
			}
			
		} 
		catch (SQLException e) 
		{
			request.setAttribute("ketqua",e.getMessage());
		}
		
		return list;
	}
	
	//tim kiem bai tap nghe
		public static List<Listenexercise> displayListenexerciseResult (HttpServletRequest request,Connection conn, String name3)
		{
			List<Listenexercise> list = new ArrayList<Listenexercise>();
			
			String sql = "select * from listenexercise where listenexercisename like '%"+name3+"%'";
			try 
			{
				PreparedStatement ptmt = conn.prepareStatement(sql);
				
				ResultSet rs = ptmt.executeQuery();
				
				if (!rs.isBeforeFirst())
				{
					request.setAttribute("ketqua","Không có kết quả");
				}
				else 
				{
					while (rs.next())
					{
						Listenexercise listenexercise = new Listenexercise();
						int listenexerciseid = rs.getInt("listenexerciseid");
						String listenexercisename = rs.getString("listenexercisename");
						String listenexerciseimage = rs.getString("listenexerciseimage");

						listenexercise.setListenexerciseid(listenexerciseid);
						listenexercise.setListenexercisename(listenexercisename);
						listenexercise.setListenexerciseimage(listenexerciseimage);
						
						list.add(listenexercise);
					}
				}
				
			} 
			catch (SQLException e) 
			{
				request.setAttribute("ketqua",e.getMessage());
			}
			
			return list;
		}
		
		//tim kiem de thi
		public static List<Examination> displayExaminationResult (HttpServletRequest request,Connection conn, String name4)
		{
			List<Examination> list = new ArrayList<Examination>();
			
			String sql = "select * from examination where examinationame like '%"+name4+"%'";
			try 
			{
				PreparedStatement ptmt = conn.prepareStatement(sql);
				
				ResultSet rs = ptmt.executeQuery();
				
				if (!rs.isBeforeFirst())
				{
					request.setAttribute("ketqua","Không có kết quả");
				}
				else 
				{
					while (rs.next())
					{
						Examination examination = new Examination();
						int examinationid = rs.getInt("examinationid");
						String examinationame = rs.getString("examinationame");
						String examinatioimage = rs.getString("examinatioimage");

						examination.setExaminationid(examinationid);
						examination.setExaminationame(examinationame);
						examination.setExaminatioimage(examinatioimage);
						
						list.add(examination);
					}
				}
				
			} 
			catch (SQLException e) 
			{
				request.setAttribute("ketqua",e.getMessage());
			}
			
			return list;
		}
}
