package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cmtgrammar;
import dao.BaihdnguphapDAO;
import dao.CommentgrammarDAO;
import db.DBConnection;


@WebServlet("/Chitietbaihdnguphapforward")
public class Chitietbaihdnguphapforward extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
   
    public Chitietbaihdnguphapforward() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String mabaihdnguphapstr = request.getParameter("mabaihdnguphap");
		
		int mabaihdnguphap = Integer.parseInt(mabaihdnguphapstr);
		
		Connection conn = DBConnection.CreateConnection();
		
		String content = BaihdnguphapDAO.displayGrammarContent(conn, mabaihdnguphap);
		
		//xuat so binh luan cua bai viet
		int countrow = CommentgrammarDAO.countRow(conn, mabaihdnguphap);
		
		request.setAttribute("mabaihdnguphap",mabaihdnguphap);
		request.setAttribute("grammarguidelinecontent",content);
		request.setAttribute("kitutrongdatabase","\n");
		request.setAttribute("kitutronghtml","<br/>");
		
		//Kí tự in đậm
		request.setAttribute("kitutrongdatabase1","**");
		request.setAttribute("kitutronghtml1","<b>");
		request.setAttribute("kitutrongdatabase2","<b><br/>");
		request.setAttribute("kitutronghtml2","</b><br/>");
		
		//Kí tự vừa in đậm vừa in nghiêng
		request.setAttribute("kitutrongdatabase3","_");
		request.setAttribute("kitutronghtml3","<i>");
		request.setAttribute("kitutrongdatabase4","<i></b>");
		request.setAttribute("kitutronghtml4","</i></b>");
		
		request.setAttribute("kitutrongdatabase7","<b><i><br/>");
		request.setAttribute("kitutronghtml7","</b></i><br/>");
		
		//Kí tự in nghiêng
		request.setAttribute("kitutrongdatabase5","_");
		request.setAttribute("kitutronghtml5","<i>");
		request.setAttribute("kitutrongdatabase6","<i><br/>");
		request.setAttribute("kitutronghtml6","</i></br>");
		
		
		request.setAttribute("countrow",countrow);
		
		
		List<Cmtgrammar> list = BaihdnguphapDAO.displayCmtgrammar(conn, mabaihdnguphap);
		
		request.setAttribute("listcommentgrammar",list);
		
		RequestDispatcher rd = request.getRequestDispatcher("View/Chitietbaihdnguphap.jsp");
		rd.forward(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
