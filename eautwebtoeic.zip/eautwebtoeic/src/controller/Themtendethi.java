package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Examination;
import dao.QuanlydethiDAO;
import db.DBConnection;


@WebServlet("/Themtendethi")
public class Themtendethi extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   
    public Themtendethi() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		if (request.getCharacterEncoding()==null)
		{
			request.setCharacterEncoding("UTF-8");
		}
		
		Connection conn = DBConnection.CreateConnection();
		
		String examinationame = request.getParameter("examinationame");
		
		//kiem tra ten de moi co bi trung voi ten de da co trong danh sach database hay khong
		Examination checkExaminationName = QuanlydethiDAO.checkExaminationNameExist(request, conn, examinationame);
		if(checkExaminationName == null) {
			
			//them ten de thi
			Examination examination = new Examination();
			examination.setExaminationame(examinationame);
			
			try 
			{
				boolean kt = QuanlydethiDAO.Themtendethi(request, conn, examination);
				
				if (kt)
				{
					int examinationid = QuanlydethiDAO.Xuatmadethi(request, conn, examination);
					
					QuanlydethiDAO.Kiemtracauhoidethi(request, conn,0, examinationid);
					QuanlydethiDAO.Kiemtraaudiohinhanhdethi(request, conn, 0, examinationid);
					
					request.setAttribute("examinationid", examinationid);
					
					RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Themhinhdethi.jsp");
					rd.forward(request,response);
				}
				else
				{
					request.setAttribute("msgquanlydethi","Thêm không thành công");
					RequestDispatcher rd = request.getRequestDispatcher("Hienthidsquanlydethi?pageid=1");
					rd.forward(request,response);
				}
				
				conn.close();
			} 
			catch (SQLException e) 
			{	
				request.setAttribute("msgquanlydethi",e.getMessage());
				RequestDispatcher rd = request.getRequestDispatcher("Hienthidsquanlydethi?pageid=1");
				rd.forward(request,response);
			}
		} else {
			request.setAttribute("msgquanlydethi","Tên đề thi này đã tồn tại.");
			//RequestDispatcher rd = request.getRequestDispatcher("Hienthidsquanlydethi?pageid=1");
			RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Quanlydethi.jsp");
			rd.forward(request,response);
		}
		
		
	}

}
