package controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.QuanlydethiDAO;
import db.DBConnection;

@WebServlet("/Xoadethi")
public class Xoadethi extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Xoadethi() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = DBConnection.CreateConnection();
		
		String examinationidstr = request.getParameter("examinationid");
		int examinationid = Integer.parseInt(examinationidstr);
		
		try {
			QuanlydethiDAO.xoaMaDeThiTrongExaminationQuestion(conn, examinationid);
			QuanlydethiDAO.xoaMaDeThiTrongResult(conn, examinationid);
			QuanlydethiDAO.xoaDeThi(conn, examinationid);
			
			RequestDispatcher rd = request.getRequestDispatcher("Hienthidsquanlydethi?pageid=1");
			rd.forward(request, response);
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
