package controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.GrammarguidelinemanageDAO;
import db.DBConnection;

@WebServlet("/UploadAnhHDNPController")
public class UploadAnhHDNPController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UploadAnhHDNPController() {
        super();
    }
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = DBConnection.CreateConnection();
		String grammarguidelineidstr = request.getParameter("grammarguidelineid");
		int grammarguidelineid = Integer.parseInt(grammarguidelineidstr);
		
		String test = GrammarguidelinemanageDAO.uploadImageGrammerguideline(conn, request, response, grammarguidelineid);
		
		
		if (test.equals("Success"))
		{
			response.sendRedirect("DSQLHDnguphapforward?pageid=1");
			
			 //RequestDispatcher rd = request.getRequestDispatcher("DSQLHDnguphapforward?pageid=1");
			 //rd.forward(request,response);
			 
		}
		else 
		{
			request.setAttribute("msgrammarguidelineimage",test);
			request.setAttribute("grammarguidelineid", grammarguidelineid);
	    	RequestDispatcher rd = request.getRequestDispatcher("View/Admin/ThemAnhBaiHDNP.jsp");
			rd.forward(request,response);		 
		}
		
	}

}
