package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Listenexercise;
import dao.SearchDAO;
import db.DBConnection;

@WebServlet("/SearchBTNghe")
public class SearchBTNghe extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public SearchBTNghe() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = DBConnection.CreateConnection();

		String listenexercisename = request.getParameter("listenexercisename");

		List<Listenexercise> list = SearchDAO.displayListenexerciseResult(request, conn, listenexercisename);

		request.setAttribute("listsearch", list);

		RequestDispatcher rd = request.getRequestDispatcher("View/Ketquatimkiembtnghe.jsp");
		rd.forward(request, response);
	}

}
