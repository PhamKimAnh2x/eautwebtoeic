package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cmtvocabulary;
import dao.CommentVocabularyDAO;
import db.DBConnection;

@WebServlet("/CmtVocabularyController")
public class CmtVocabularyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public CmtVocabularyController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getCharacterEncoding()!= null)
		{
			request.setCharacterEncoding("UTF-8");
		}

		try 
		{
			String memberidstr = request.getParameter("memberid");
			String cmtvocabularycontent = request.getParameter("cmtvocabularycontent");
			String vocabularyguidelineidstr = request.getParameter("vocabularyguidelineid");
			int vocabularyguidelineid = Integer.parseInt(vocabularyguidelineidstr);
			int memberid = Integer.parseInt(memberidstr);
			
			Connection conn = DBConnection.CreateConnection();
			
			Cmtvocabulary cmtvocabulary = new Cmtvocabulary();
			
			cmtvocabulary.setCmtvocabularycontent(cmtvocabularycontent);
			cmtvocabulary.setMemberid(memberid);
			cmtvocabulary.setVocabularyguidelineid(vocabularyguidelineid);
			
			CommentVocabularyDAO.insertCmtVocabulary(request, conn, cmtvocabulary);
			
			List<Cmtvocabulary> list = CommentVocabularyDAO.displayCmtVocabulary(conn, vocabularyguidelineid);
					
			request.setAttribute("listcommentvocabulary",list);
			
			RequestDispatcher rd = request.getRequestDispatcher("View/Listcmtvocabulary.jsp");
			rd.forward(request,response);
			conn.close();
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}

	}

}
