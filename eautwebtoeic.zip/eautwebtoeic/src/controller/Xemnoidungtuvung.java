package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Cmtvocabulary;
import bean.Vocabularycontent;
import dao.CommentVocabularyDAO;
import dao.HdhoctuvungDAO;
import db.DBConnection;


@WebServlet("/Xemnoidungtuvung")
public class Xemnoidungtuvung extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Xemnoidungtuvung() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String vocabularyguidelineidstr = request.getParameter("vocabularyguidelineid");
		
		int vocabularyguidelineid = Integer.parseInt(vocabularyguidelineidstr);
		
		Connection conn = DBConnection.CreateConnection();
		
		String cmtvocabularycontent = HdhoctuvungDAO.displayVocabularyContent(conn, vocabularyguidelineid);
		
		//xuat so binh luan cua bai viet
		int countrow = CommentVocabularyDAO.Countrow(conn, vocabularyguidelineid);
		
		List<Vocabularycontent> list = HdhoctuvungDAO.Hienthinoidungtuvung(request, conn,vocabularyguidelineid);
		
		
		request.setAttribute("noidungtuvung",list);
		
		request.setAttribute("countrow",countrow);
		
		List<Cmtvocabulary> listcmt = HdhoctuvungDAO.displayCmtVocabulary(conn, vocabularyguidelineid);
		
		request.setAttribute("listcommentvocabulary", listcmt);
		request.setAttribute("vocabularyguidelineid",vocabularyguidelineid);
		
		RequestDispatcher rd = request.getRequestDispatcher("View/Noidunghdtuvung.jsp");
		rd.forward(request,response);
	}


}
