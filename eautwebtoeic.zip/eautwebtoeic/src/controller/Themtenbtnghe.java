package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Listenexercise;
import dao.QuanlybtngheDAO;
import db.DBConnection;

@WebServlet("/Themtenbtnghe")
public class Themtenbtnghe extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Themtenbtnghe() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		if (request.getCharacterEncoding()==null)
		{
			request.setCharacterEncoding("UTF-8");
		}
		Connection conn = DBConnection.CreateConnection();
		String listenexercisename = request.getParameter("listenexercisename");
		
		Listenexercise checkListenExerciseNameExist = QuanlybtngheDAO.checkGrammarNameExist(request, conn, listenexercisename);
		
		if(checkListenExerciseNameExist == null) {
			Listenexercise listenexercise = new Listenexercise();
			listenexercise.setListenexercisename(listenexercisename);
			
			try 
			{
				boolean kt = QuanlybtngheDAO.Themtenbtnghe(request, conn, listenexercise);
				
				if (kt)
				{
					int listenexerciseid = QuanlybtngheDAO.Xuatmabtnghe(request, conn, listenexercise);
					
					QuanlybtngheDAO.Kiemtracauhoibtnghe(request, conn,0, listenexerciseid);
					QuanlybtngheDAO.Kiemtraaudiohinhanhbtnghe(request, conn, 0, listenexerciseid);
					
					request.setAttribute("listenexerciseid", listenexerciseid);
					
					RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Themhinhbtnghe.jsp");
					rd.forward(request,response);
				}
				else
				{
					request.setAttribute("msgquanlydsbtnghe","Thêm không thành công");
					RequestDispatcher rd = request.getRequestDispatcher("Hienthidsbtdoc?pageid=1");
					rd.forward(request,response);
				}
				
				conn.close();
			} 
			catch (SQLException e) 
			{	
				request.setAttribute("msgquanlydsbtnghe",e.getMessage());
				RequestDispatcher rd = request.getRequestDispatcher("Hienthidsbtdoc?pageid=1");
				rd.forward(request,response);
			}
		} else {
			request.setAttribute("msgquanlydsbtnghe","Tên bài tập nghe này đã tồn tại.");
			RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Quanlylambtnghe.jsp");
			rd.forward(request,response);
		}
		
	}

}
