package controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Examination;
import dao.SearchDAO;
import db.DBConnection;

@WebServlet("/SearchDeThi")
public class SearchDeThi extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public SearchDeThi() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = DBConnection.CreateConnection();
		String examinationame = request.getParameter("examinationame");
		
		List<Examination> list = SearchDAO.displayExaminationResult(request, conn, examinationame);
		
		request.setAttribute("listsearch",list);
		
		RequestDispatcher rd = request.getRequestDispatcher("View/Ketquatimkiemdethi.jsp");
		rd.forward(request,response);

	}

}
