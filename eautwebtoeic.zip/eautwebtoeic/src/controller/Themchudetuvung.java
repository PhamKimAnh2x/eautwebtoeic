package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Vocabularyguideline;
import dao.QuanlyhdtuvungDAO;
import db.DBConnection;

@WebServlet("/Themchudetuvung")
public class Themchudetuvung extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Themchudetuvung() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		if (request.getCharacterEncoding()==null)
		{
			request.setCharacterEncoding("UTF-8");
		}
		Connection conn = DBConnection.CreateConnection();
		
		String vocabularyname = request.getParameter("vocabularyname");
		
		Vocabularyguideline checkVocabularyNameExist = QuanlyhdtuvungDAO.checkVocabularyNameExist(request, conn, vocabularyname);
		
		if(checkVocabularyNameExist==null) {
			Vocabularyguideline vocabularyguideline = new Vocabularyguideline();
			vocabularyguideline.setVocabularyname(vocabularyname);
			
			try 
			{
				boolean kt = QuanlyhdtuvungDAO.Themtenchudetuvung(request, conn, vocabularyguideline);
				
				if (kt)
				{
					int vocabularyguidelineid = QuanlyhdtuvungDAO.Xuatmachudetuvung(request, conn, vocabularyguideline);
					
					QuanlyhdtuvungDAO.Kiemtrandchudetuvung(request, conn,0, vocabularyguidelineid);
					QuanlyhdtuvungDAO.Kiemtraaudiohinhanhtuvung(request, conn, 0, vocabularyguidelineid);
					
					request.setAttribute("vocabularyguidelineid", vocabularyguidelineid);
					
					//RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Themhinhdethi.jsp");
					RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Themhinhchudetuvung.jsp");
					rd.forward(request,response);
				}
				else
				{
					request.setAttribute("msgdstuvung","Thêm chủ đề từ vựng không thành công");
					
					RequestDispatcher rd = request.getRequestDispatcher("Hienthidstuvung?pageid=1");
					rd.forward(request,response);
				}
				
				conn.close();
			} 
			catch (SQLException e) 
			{	
				request.setAttribute("msgdstuvung",e.getMessage());
				RequestDispatcher rd = request.getRequestDispatcher("Hienthidstuvung?pageid=1");
				rd.forward(request,response);
			}
		}else {
			request.setAttribute("msgdstuvung","Tên bài hướng dẫn từ vựng này đã tồn tại");
			RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Dsbaihdtuvung.jsp");
			rd.forward(request,response);
		}
		
		
	}

}
