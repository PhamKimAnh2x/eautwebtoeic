package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.QuanlybtngheDAO;
import db.DBConnection;

@WebServlet("/Xoabaitapnghe")
public class Xoabaitapnghe extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Xoabaitapnghe() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection conn = DBConnection.CreateConnection();

		String listenexerciseidstr = request.getParameter("listenexerciseid");
		int listenexerciseid = Integer.parseInt(listenexerciseidstr);

		try {
			QuanlybtngheDAO.xoaMaBTDocTrongReadQuestion(conn, listenexerciseid);
			QuanlybtngheDAO.xoaBaiTapNghe(conn, listenexerciseid);

			response.sendRedirect("Hienthidsquanlybtnghe?pageid=1");

			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
