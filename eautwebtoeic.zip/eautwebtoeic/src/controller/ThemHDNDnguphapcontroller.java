package controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Grammarguideline;
import dao.GrammarguidelinemanageDAO;
import db.DBConnection;

@WebServlet("/ThemHDNDnguphapcontroller")
public class ThemHDNDnguphapcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ThemHDNDnguphapcontroller() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (request.getCharacterEncoding() == null) {
			request.setCharacterEncoding("UTF-8");
		}
		Connection conn = DBConnection.CreateConnection();
		
		//response.setContentType("text/html; charset=UTF-8");
		//request.setCharacterEncoding("UTF-8");
		//response.setCharacterEncoding("UTF-8");

		String content = request.getParameter("content");
		String grammarguidelineidstr = request.getParameter("grammarguidelineid");
		
		int grammarguidelineid = Integer.parseInt(grammarguidelineidstr);

		Grammarguideline grammarguideline = new Grammarguideline();
		grammarguideline.setContent(content);
		
		boolean kt = GrammarguidelinemanageDAO.insertGrammarguidelineContent(request, conn, grammarguideline, grammarguidelineid);
		if(kt) {
			response.sendRedirect("DSQLHDnguphapforward?pageid=1");
			//RequestDispatcher rd = request.getRequestDispatcher("DSQLHDnguphapforward");
			//rd.forward(request, response);
		} else {
			request.setAttribute("msggrammarguidelinecontent","Thêm nội dung không thành công.");
			request.setAttribute("grammarguidelineid",grammarguidelineid);
			RequestDispatcher rd = request.getRequestDispatcher("View/Admin/ThemHDNDnguphap.jsp");
			rd.forward(request,response);	
		}
	}

}
