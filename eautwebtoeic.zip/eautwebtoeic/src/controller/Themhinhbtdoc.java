package controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.QuanlybtdocDAO;
import db.DBConnection;

@WebServlet("/Themhinhbtdoc")
public class Themhinhbtdoc extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public Themhinhbtdoc() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		Connection conn = DBConnection.CreateConnection();
		
		String readexeriseidstr = request.getParameter("readexeriseid");
		int readexeriseid = Integer.parseInt(readexeriseidstr);
			
		String test = QuanlybtdocDAO.Themhinhbtdoc(conn, request, response, readexeriseid);
		
		if (test.equals("Success"))
		{
			response.sendRedirect("Hienthidsbtdoc?pageid=1");
			//RequestDispatcher rd = request.getRequestDispatcher("Hienthidsbtdoc?pageid=1");
			//rd.forward(request,response);	
		}
		else 
		{
			request.setAttribute("msgthemhinhbtdoc",test);
			request.setAttribute("readexeriseid", readexeriseid);
	    	RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Themhinhbtdoc.jsp");
			rd.forward(request,response);		 
		}
	}

}
