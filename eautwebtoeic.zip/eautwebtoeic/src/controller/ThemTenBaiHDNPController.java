package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Grammarguideline;
import dao.GrammarguidelinemanageDAO;
import db.DBConnection;

@WebServlet("/ThemTenBaiHDNPController")
public class ThemTenBaiHDNPController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ThemTenBaiHDNPController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getCharacterEncoding()==null) {
			request.setCharacterEncoding("UTF-8");
		}
		Connection conn = DBConnection.CreateConnection();
		
		String grammarname = request.getParameter("grammarname");
		
		Grammarguideline checkGrammarName = GrammarguidelinemanageDAO.checkGrammarNameExist(request, conn, grammarname);
		
		if(checkGrammarName == null) {
			Grammarguideline grammarguideline = new Grammarguideline();
			grammarguideline.setGrammarname(grammarname);
			
			try {
				boolean kt = GrammarguidelinemanageDAO.insertGrammarguidelineName(request, conn, grammarguideline);
				
				if(kt) {
					
					int grammarguidelineid = GrammarguidelinemanageDAO.retrieveIdGrammarguideline(request, conn, grammarguideline);
					request.setAttribute("grammarguidelineid", grammarguidelineid);
					
					RequestDispatcher rd = request.getRequestDispatcher("View/Admin/ThemAnhBaiHDNP.jsp");
					rd.forward(request,response);
				}
				else {
					request.setAttribute("msglistgrammarguidelinemanage", "Thêm không thành công");
					RequestDispatcher rd = request.getRequestDispatcher("DSQLHDnguphapforward?pageid=1");
					rd.forward(request,response);
				}
				conn.close();
				
			} catch (SQLException e) {
				request.setAttribute("msglistgrammarguidelinemanage", e.getMessage());
				RequestDispatcher rd = request.getRequestDispatcher("DSQLHDnguphapforward?pageid=1");
				rd.forward(request,response);
			}
		} else {
			
			 request.setAttribute("msglistgrammarguidelinemanage","Tên bài hướng dẫn ngữ pháp này đã tồn tại"); 
			 //RequestDispatcher rd = request.getRequestDispatcher("DSQLHDnguphapforward?pageid=1");
			 RequestDispatcher rd = request.getRequestDispatcher("View/Admin/DSQLHDnguphap.jsp");
			 rd.forward(request,response);
			 
		}
	}

}
