package controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Readexercise;
import dao.QuanlybtdocDAO;
import db.DBConnection;

@WebServlet("/Themtenbtdoc")
public class Themtenbtdoc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Themtenbtdoc() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		if (request.getCharacterEncoding()==null)
		{
			request.setCharacterEncoding("UTF-8");
		}
		Connection conn = DBConnection.CreateConnection();
		
		String readname = request.getParameter("readname");
		
		Readexercise checkReadNameExist = QuanlybtdocDAO.checkReadNameExist(request, conn, readname);
		
		if(checkReadNameExist == null) {
			Readexercise readexercise = new Readexercise();
			readexercise.setReadname(readname);
			
			
			try 
			{
				boolean kt = QuanlybtdocDAO.Themtenbtdoc(request, conn, readexercise);
				
				if (kt)
				{
					int readexeriseid = QuanlybtdocDAO.Xuatmabtdoc(request, conn, readexercise);
					
					QuanlybtdocDAO.Kiemtracauhoibtdoc(request, conn, 0, readexeriseid);
					
					
					request.setAttribute("readexeriseid", readexeriseid);
					
					RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Themhinhbtdoc.jsp");
					rd.forward(request,response);
				}
				else
				{
					request.setAttribute("msgquanlydsbtdoc","Thêm không thành công");
					RequestDispatcher rd = request.getRequestDispatcher("Hienthidsbtdoc?pageid=1");
					rd.forward(request,response);
				}
				
				conn.close();
			} 
			catch (SQLException e) 
			{	
				request.setAttribute("msgquanlydsbtdoc",e.getMessage());
				RequestDispatcher rd = request.getRequestDispatcher("Hienthidsbtdoc?pageid=1");
				rd.forward(request,response);
			}
		} else {
			request.setAttribute("msgquanlydsbtdoc","Tên bài tập đọc này đã tồn tại.");
			RequestDispatcher rd = request.getRequestDispatcher("View/Admin/Quanlylambtdoc.jsp");
			rd.forward(request,response);
		}
		
	}

}
