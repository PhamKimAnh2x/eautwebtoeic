package bean;

public class Readexercise 
{
	private int readexeriseid;
	private String readname;
	private String readimage;
	private int checkcauhoi;
	
	public Readexercise() {
		// TODO Auto-generated constructor stub
	}
	
	public Readexercise(int readexeriseid, String readname, String readimage, int checkcauhoi) {
		super();
		this.readexeriseid = readexeriseid;
		this.readname = readname;
		this.readimage = readimage;
		this.checkcauhoi = checkcauhoi;
	}

	public int getReadexeriseid() {
		return readexeriseid;
	}
	public void setReadexeriseid(int readexeriseid) {
		this.readexeriseid = readexeriseid;
	}
	public String getReadname() {
		return readname;
	}
	public void setReadname(String readname) {
		this.readname = readname;
	}
	public String getReadimage() {
		return readimage;
	}
	public void setReadimage(String readimage) {
		this.readimage = readimage;
	}
	public int getCheckcauhoi() {
		return checkcauhoi;
	}
	public void setCheckcauhoi(int checkcauhoi) {
		this.checkcauhoi = checkcauhoi;
	}
}
