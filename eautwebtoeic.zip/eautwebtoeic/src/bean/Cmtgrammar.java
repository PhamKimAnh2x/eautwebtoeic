package bean;

public class Cmtgrammar 
{
		private int cmtgrammarid;
		private String cmtgrammarcontent;
		private int memberid;
		private int grammarguidelineid;
		private String name; //là name của bảng member
		
		public int getCmtgrammarid() {
			return cmtgrammarid;
		}
		public void setCmtgrammarid(int cmtgrammarid) {
			this.cmtgrammarid = cmtgrammarid;
		}
		public String getCmtgrammarcontent() {
			return cmtgrammarcontent;
		}
		public void setCmtgrammarcontent(String cmtgrammarcontent) {
			this.cmtgrammarcontent = cmtgrammarcontent;
		}
		public int getMemberid() {
			return memberid;
		}
		public void setMemberid(int memberid) {
			this.memberid = memberid;
		}
		public int getGrammarguidelineid() {
			return grammarguidelineid;
		}
		public void setGrammarguidelineid(int grammarguidelineid) {
			this.grammarguidelineid = grammarguidelineid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
}
