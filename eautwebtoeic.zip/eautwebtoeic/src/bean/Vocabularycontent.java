package bean;

public class Vocabularycontent 
{
		private int vocabularycontentid;
		private int num;
		private String vocabularycontentname;
		private String transcribe;
		private String image;
		private String audiomp3;
		private String audiogg;
		private String mean;
		private int vocabularyguidelineid;
		
		
		
		public int getVocabularycontentid() {
			return vocabularycontentid;
		}
		public void setVocabularycontentid(int vocabularycontentid) {
			this.vocabularycontentid = vocabularycontentid;
		}
		public int getNum() {
			return num;
		}
		public void setNum(int num) {
			this.num = num;
		}
		public String getVocabularycontentname() {
			return vocabularycontentname;
		}
		public void setVocabularycontentname(String vocabularycontentname) {
			this.vocabularycontentname = vocabularycontentname;
		}
		public String getTranscribe() {
			return transcribe;
		}
		public void setTranscribe(String transcribe) {
			this.transcribe = transcribe;
		}
		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public String getAudiomp3() {
			return audiomp3;
		}
		public void setAudiomp3(String audiomp3) {
			this.audiomp3 = audiomp3;
		}
		public String getAudiogg() {
			return audiogg;
		}
		public void setAudiogg(String audiogg) {
			this.audiogg = audiogg;
		}
		public String getMean() {
			return mean;
		}
		public void setMean(String mean) {
			this.mean = mean;
		}
		public int getVocabularyguidelineid() {
			return vocabularyguidelineid;
		}
		public void setVocabularyguidelineid(int vocabularyguidelineid) {
			this.vocabularyguidelineid = vocabularyguidelineid;
		}
		
		
}
