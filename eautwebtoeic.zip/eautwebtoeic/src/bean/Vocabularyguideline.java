package bean;

public class Vocabularyguideline 
{
	private int vocabularyguidelineid;
	private String vocabularyname;
	private String vocabularyimage;
	private int checknoidung;
	private int checkaudiohinhanh;
	
	public Vocabularyguideline() {
	}
	
	public Vocabularyguideline(int vocabularyguidelineid, String vocabularyname, String vocabularyimage,
			int checknoidung, int checkaudiohinhanh) {
		super();
		this.vocabularyguidelineid = vocabularyguidelineid;
		this.vocabularyname = vocabularyname;
		this.vocabularyimage = vocabularyimage;
		this.checknoidung = checknoidung;
		this.checkaudiohinhanh = checkaudiohinhanh;
	}
	public int getCheckaudiohinhanh() {
		return checkaudiohinhanh;
	}
	public void setCheckaudiohinhanh(int checkaudiohinhanh) {
		this.checkaudiohinhanh = checkaudiohinhanh;
	}
	public int getVocabularyguidelineid() {
		return vocabularyguidelineid;
	}
	public void setVocabularyguidelineid(int vocabularyguidelineid) {
		this.vocabularyguidelineid = vocabularyguidelineid;
	}
	public String getVocabularyname() {
		return vocabularyname;
	}
	public void setVocabularyname(String vocabularyname) {
		this.vocabularyname = vocabularyname;
	}
	public String getVocabularyimage() {
		return vocabularyimage;
	}
	public void setVocabularyimage(String vocabularyimage) {
		this.vocabularyimage = vocabularyimage;
	}
	public int getChecknoidung() {
		return checknoidung;
	}
	public void setChecknoidung(int checknoidung) {
		this.checknoidung = checknoidung;
	}
}
