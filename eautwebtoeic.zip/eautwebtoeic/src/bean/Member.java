package bean;

public class Member 
{
		private int memberid;
		private String name;
		private String membername;
		private String memberpass;
		private int categorymemberid;
		
		public Member() {
		}
		public Member(int memberid, String name, String membername, String memberpass, int categorymemberid) {
			super();
			this.memberid = memberid;
			this.name = name;
			this.membername = membername;
			this.memberpass = memberpass;
			this.categorymemberid = categorymemberid;
		}

		public int getMemberid() {
			return memberid;
		}
		public void setMemberid(int memberid) {
			this.memberid = memberid;
		}
		public String getMembername() {
			return membername;
		}
		public void setMembername(String membername) {
			this.membername = membername;
		}
		public String getMemberpass() {
			return memberpass;
		}
		public void setMemberpass(String memberpass) {
			this.memberpass = memberpass;
		}
		public int getCategorymemberid() {
			return categorymemberid;
		}
		public void setCategorymemberid(int categorymemberid) {
			this.categorymemberid = categorymemberid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		
}
