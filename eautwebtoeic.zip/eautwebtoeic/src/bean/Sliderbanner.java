package bean;

public class Sliderbanner 
{
	private int slidebannerid;
	private String slidename;
	private String slidecontent;
	private String slideimage;
	public int getSlidebannerid() {
		return slidebannerid;
	}
	public void setSlidebannerid(int slidebannerid) {
		this.slidebannerid = slidebannerid;
	}
	public String getSlidename() {
		return slidename;
	}
	public void setSlidename(String slidename) {
		this.slidename = slidename;
	}
	public String getSlidecontent() {
		return slidecontent;
	}
	public void setSlidecontent(String slidecontent) {
		this.slidecontent = slidecontent;
	}
	public String getSlideimage() {
		return slideimage;
	}
	public void setSlideimage(String slideimage) {
		this.slideimage = slideimage;
	}
	
	
}
