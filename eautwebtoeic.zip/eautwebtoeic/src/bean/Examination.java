package bean;

public class Examination 
{
	private int examinationid;
	private String examinationame;
	private String examinatioimage;
	private int checkedcauhoi;
	private int checkedaudiohinhanh;

	public Examination() {
	}
	
	public Examination(int examinationid, String examinationame, String examinatioimage, int checkedcauhoi, int checkedaudiohinhanh) {
		super();
		this.examinationid = examinationid;
		this.examinationame = examinationame;
		this.examinatioimage = examinatioimage;
		this.checkedcauhoi = checkedcauhoi;
		this.checkedaudiohinhanh = checkedaudiohinhanh;
	}

	public int getExaminationid() {
		return examinationid;
	}
	public void setExaminationid(int examinationid) {
		this.examinationid = examinationid;
	}
	public String getExaminationame() {
		return examinationame;
	}
	public void setExaminationame(String examinationame) {
		this.examinationame = examinationame;
	}
	public String getExaminatioimage() {
		return examinatioimage;
	}
	public void setExaminatioimage(String examinatioimage) {
		this.examinatioimage = examinatioimage;
	}
	public int getCheckedcauhoi() {
		return checkedcauhoi;
	}
	public void setCheckedcauhoi(int checkedcauhoi) {
		this.checkedcauhoi = checkedcauhoi;
	}
	public int getCheckedaudiohinhanh() {
		return checkedaudiohinhanh;
	}
	public void setCheckedaudiohinhanh(int checkedaudiohinhanh) {
		this.checkedaudiohinhanh = checkedaudiohinhanh;
	}
}
