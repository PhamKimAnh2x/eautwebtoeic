package bean;

public class Listenexercise 
{
	private int listenexerciseid;
	private String listenexercisename;
	private String listenexerciseimage;
	private int checkcauhoi;
	private int checkaudiohinhanh;
	
	public Listenexercise() {
	}
	
	public Listenexercise(int listenexerciseid, String listenexercisename, String listenexerciseimage, int checkcauhoi,
			int checkaudiohinhanh) {
		super();
		this.listenexerciseid = listenexerciseid;
		this.listenexercisename = listenexercisename;
		this.listenexerciseimage = listenexerciseimage;
		this.checkcauhoi = checkcauhoi;
		this.checkaudiohinhanh = checkaudiohinhanh;
	}

	public int getCheckaudiohinhanh() {
		return checkaudiohinhanh;
	}
	public void setCheckaudiohinhanh(int checkaudiohinhanh) {
		this.checkaudiohinhanh = checkaudiohinhanh;
	}
	public int getListenexerciseid() {
		return listenexerciseid;
	}
	public void setListenexerciseid(int listenexerciseid) {
		this.listenexerciseid = listenexerciseid;
	}
	public String getListenexercisename() {
		return listenexercisename;
	}
	public void setListenexercisename(String listenexercisename) {
		this.listenexercisename = listenexercisename;
	}
	public String getListenexerciseimage() {
		return listenexerciseimage;
	}
	public void setListenexerciseimage(String listenexerciseimage) {
		this.listenexerciseimage = listenexerciseimage;
	}
	public int getCheckcauhoi() {
		return checkcauhoi;
	}
	public void setCheckcauhoi(int checkcauhoi) {
		this.checkcauhoi = checkcauhoi;
	}
}
